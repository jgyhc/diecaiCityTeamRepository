//
//  AppDelegate.h
//  VideoDownloader
//
//  Created by Jack Cox on 4/5/12.
//   
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
