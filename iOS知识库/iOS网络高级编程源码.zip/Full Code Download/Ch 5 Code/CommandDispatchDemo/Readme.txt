CommandDispatchDemo

The entire contents of this directory tree are required to run the command dispatch demo described in
Chapter 5 of Professional iOS Network Programming.  

To begin examining the code open the CommandDispatchDemo.xcodeproj file using XCode 4.3.2 or higher.

