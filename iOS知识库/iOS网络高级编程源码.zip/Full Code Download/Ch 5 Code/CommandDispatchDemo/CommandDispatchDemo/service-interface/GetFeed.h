//
//  GetFeed.h
//  CommandDispatchDemo
//
//  Created by Jack Cox on 9/10/11.
//  
//

#import "BaseCommand.h"

@interface GetFeed : BaseCommand

@end
