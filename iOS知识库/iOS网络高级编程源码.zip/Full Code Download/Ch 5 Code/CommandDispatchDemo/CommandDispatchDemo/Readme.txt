The associated project is a example of the Command Dispatch error handling pattern.
The code was written for iOS 4.3 using XCode 4.1.
