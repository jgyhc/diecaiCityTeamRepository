//
//  HelpRequestTableViewController.h
//  consumer-help
//
//  Created by Nathan Jones on 7/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelpRequestTableViewController : UITableViewController

@end