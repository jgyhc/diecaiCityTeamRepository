//
//  HelpResponse.h
//  associate-help
//
//  Created by Nathan Jones on 7/15/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelpResponse : NSObject <NSCoding>

@property(nonatomic,assign) BOOL    response;

@end